//This police station mangement system is purely used by concepts of object oriented programming
//and overcomes all topics we have studies right now 

//Haseeb Manzoor Ahmed     l1f16bscs0080       sec:A      UNIVERSITY OF CENTRAL PUNJAB, LAHORE
#include <iostream>
#include <fstream>
#include "court.h"
#include "criminal.h"
#include "Date.h"
#include "detailscriminal.h"
#include "police.h"

using namespace std;
int main()
{
	criminal obj;
	obj.input();
	obj.menu();
	cout << endl;

	obj.output;
	{
		system("pause");
	}
	return 0;
}